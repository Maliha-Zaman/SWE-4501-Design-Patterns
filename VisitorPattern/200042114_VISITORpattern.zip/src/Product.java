public interface Product {
    void accept(ShippingVisitor visitor);
}
