public class FanDemo {
    public static void main(String[] args) {
        FanContext fanContext = new FanContext();

        fanContext.changeSpeed();
        fanContext.changeSpeed();
        fanContext.changeSpeed();
        fanContext.changeSpeed();
    }
}
