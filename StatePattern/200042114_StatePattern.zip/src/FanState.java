interface FanState {
    void changeSpeed(FanContext context);
}
